package com.example.twomack.nycschooldataviewer;

/**
 * Created by swaitkus on 2/20/18.
 * This class is intentionally left empty. It's purpose is to be a source of extension for the CallBackWrapper
 */

public class BaseResponse {
}
